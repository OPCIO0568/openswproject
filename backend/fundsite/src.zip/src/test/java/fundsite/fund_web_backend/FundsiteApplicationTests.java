package fundsite.fund_web_backend;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class FundsiteApplicationTests {



    
}

