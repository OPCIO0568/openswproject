package fundsite.fund_web_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FundsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(FundsiteApplication.class, args);
	}

}
