package fundsite.fund_web_backend.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@Service
public class FileService {
    private final String uploadDir = "static/images/";

    public String saveFile(MultipartFile file, Long donationId) throws Exception {
        // Generate folder path using donation ID
        String folderPath = Paths.get(uploadDir, String.valueOf(donationId)).toString();

        // Generate unique file name
        String fileName = UUID.randomUUID().toString() + "_" + file.getOriginalFilename();
        Path filePath = Paths.get(folderPath, fileName);

        // Create directories if they do not exist
        Files.createDirectories(filePath.getParent());

        // Save the file
        Files.write(filePath, file.getBytes());

        // Return the relative path to the saved file
        return folderPath + "/" + fileName;
    }
}